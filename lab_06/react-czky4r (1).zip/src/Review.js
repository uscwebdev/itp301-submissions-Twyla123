import React from 'react';

export default function Review(prop){
  return (
    <div className="review">
    <img src={prop.src} alt={prop.userName + " Profile Image"}/>
    <h4>Username: {prop.userName} </h4>
    <p>Date: {prop.date}</p>
    <p> {prop.content}</p>
    </div>
    
  );
}