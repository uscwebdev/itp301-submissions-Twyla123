import React from 'react';
import { createRoot } from 'react-dom/client';
import Review from "./Review.js";
import './index.css'

const root = createRoot(document.querySelector('#root'));


root.render(
  <React.StrictMode>
    <div id="container">
    <h1 class="center">Comment on Makeup Products</h1>

    <p id='intro'>Welcome to the ultimate destination for makeup enthusiasts! If you've ever found yourself overwhelmed by the countless makeup products available in the market, unsure of which ones best fits you, you've come to the right place. Our website is dedicated to providing you with real user comments and reviews for makeup products. Whether you're searching for perfect foundation or a skincare routine, we're here to help you make the best choices for your. Our website is authentic, honest, and user-driven! </p>

    <div className="block">
    <img src="https://m.media-amazon.com/images/I/51sezTxYJsL.jpg" alt="Foundation"/>
    <h3 class="center">Maybelline Fit Me Matte + Poreless Liquid Foundation</h3>
    <h4>About</h4>
    <p>Fit Me® Matte + Poreless Foundation face makeup. This lightweight foundation mattifies and refines pores and leaves a natural, seamless finish(From Maybelline official website). <a href="https://www.maybelline.com/face-makeup/foundation-makeup/fit-me-matte-poreless-foundation?GeoRedirectOff=True&gclid=CjwKCAjwsKqoBhBPEiwALrrqiPnxe_yJ6YgDoFF39Ag1je33yy_jPKGlxu6Y_iCV1ldqMN9qPwiLShoC9hgQAvD_BwE&gclsrc=aw.ds&variant=Warm+Sun">Buy it now!</a></p>
    </div>

    <div className="block">
    <img src="https://im.idiva.com/content/2022/Dec/googledocmediakix4qr49b4jbigs_639c784dc544d.jpg" alt="Eyeshadow"/>
    <h3 class="center">HUDA BEAUTY Empowered Eyeshadow Palette</h3>
    <h4>About</h4>
    <p>The ultimate everyday palette! Own your power with this luxurious line-up of buttery-smooth golds, coppers, browns, and neutrals in a variety of textures including intensely pigmented mattes, creamy gel-liner hybrids, foiled chrome metallics, AND a blingy wet-look shimmer(From HUDA BEAUTY official website). <a href="https://hudabeauty.com/us/en_US/eyeshadow/empowered-eyeshadow-palette-HB00930.html">Buy it now!</a> </p>
    </div>


    <div className="block">
    <img src="https://www.sephora.com/productimages/sku/s2296986-main-zoom.jpg?imwidth=630" alt="Blush"/>
    <h3 class="center">Nars Blush</h3>
    <h4>About</h4>
    <p>Buildable. Blendable. Indispensible. Uncover the best in glow. Our cult-favorite, bestselling NARS Blush delivers a weightless, natural-looking rush of cheek color in matte, satin, and shimmering finishes. Superfine micronized powder pigments ensure an irresistibly soft, blendable application. Buildable shades from sheer to bold deliver a natural wash of color to every skin tone—a light swipe of even the highest-intensity hues deliver a natural-looking flush. Superfine and silky powder. Irresistible and inimitable. Blush is the new bold.(From Nars official website). <a href="https://www.narscosmetics.com/USA/blush/999NACBLUSH01.html?dwvar_999NACBLUSH01_color=7845040132&cgid=blush">Buy it now!</a></p> 
    </div>

    <div className="left">
    <Review src="https://e7.pngegg.com/pngimages/168/827/png-clipart-computer-icons-user-profile-avatar-profile-woman-desktop-wallpaper-thumbnail.png" userName="GlamourGaze" date="9/20/2023" content="NARS blush is an absolute must-have for any makeup collection. Its finely milled formula blends effortlessly, delivering a natural flush of color that lasts all day, making it a staple for achieving that radiant, healthy glow."/>

    <Review src="https://img.freepik.com/premium-vector/account-icon-user-icon-vector-graphics_292645-552.jpg?w=2000" userName="RadiantPalette" date="9/10/2020" content="Flawless Canvas Every Time! Five Star! I've been using Maybelline's Fit Me for quite some time now, and I must say, it's become an absolute staple in my makeup routine. This foundation has completely transformed the way I look at face makeup" />
    </div>

    <div className="clear"></div>

  <div className="left">
    <Review src="https://static01.nyt.com/images/2021/09/14/science/07CAT-STRIPES/07CAT-STRIPES-jumbo.jpg?quality=75&auto=webp" userName="BeautyEnthusiast24" date="6/20/2019" content="The Fit Me Foundation by Maybelline is a true gem in the world of drugstore makeup. Its lightweight formula provides excellent coverage while allowing your skin to breathe, making it ideal for everyday wear. With its extensive shade range and affordable price, it's a versatile foundation that caters to a wide range of skin tones and budgets."/>

    <Review src="https://www.hartz.com/wp-content/uploads/2022/04/small-dog-owners-1.jpg" userName="BeautyEnthusiast19" date="5/18/2023" content="The Ultimate Everyday Palette is a game-changer for makeup enthusiasts. The shades in golds, coppers, browns, and neutrals offers endless possibilities for both natural and bold looks." />
    </div>

  </div>
  </React.StrictMode>


);



