import React from 'react';

export default function Product (props) {
 return ( <div className="item">
  <img src={props.src} alt= {props.name + " image"} />
  <h3>{props.name}</h3>
  <h4>Price: ${props.price}</h4>

  </div>)

}