import React from 'react';
import { createRoot } from 'react-dom/client';
import './index.css'


const root = createRoot(document.querySelector('#root'));


root.render(
  <React.StrictMode>
    <div id="container">
      <h1 id="name">Twyla Zhang</h1>

      {/*  Hyperlink to my email  */}
      <p> email: <a href="mailto:twylazha@usc.edu">twylazha@usc.edu</a>. </p>

      {/* favorite color */}
      <div class="fav-color">
          <p>Favorite Color: Blue</p>
      </div>

      {/*  favorite website */}
      <p> favorite website: <a href="https://www.netflix.com/" target="_blank">Netflix</a></p>

      {/*  favorite activity */}
      <p>favorite activity:</p>
      <img src="https://media.timeout.com/images/105942909/750/422/image.jpg" alt="IceSkating" />


      {/* List of classes enrolled */}
      <p>Classes</p>
      <ul>
          <li>ITP301</li>
          <li>EASC150</li>
          <li>DS250</li>
          <li>Econ318</li>
          <li>Phed123</li>
      </ul>

  </div>



  </React.StrictMode> 
  

);
